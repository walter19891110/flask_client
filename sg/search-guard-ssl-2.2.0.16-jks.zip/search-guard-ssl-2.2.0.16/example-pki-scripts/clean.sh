#!/bin/sh
rm -rf ca/
rm -rf certs/
rm -rf crl/
rm -f *.jks
rm -f *.pem
rm -f *.p12
rm -f *.csr

